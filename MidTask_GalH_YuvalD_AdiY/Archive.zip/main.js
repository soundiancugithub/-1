/* =========================================
   SCORM handling
   ========================================= */
let scormConnected = false;

// ניסיון חיבור ל-LMS (SCORM 1.2) ברגע שהעמוד נטען
function initScorm() {
    if (!window.pipwerks || !pipwerks.SCORM) {
        console.log("SCORM wrapper not found – running in demo mode.");
        scormConnected = false;
        return;
    }

    pipwerks.SCORM.version = "1.2";
    scormConnected = pipwerks.SCORM.init();

    if (scormConnected) {
        console.log("SCORM connection established.");
        // סטטוס ראשוני – כמו במצגות
        pipwerks.SCORM.set("cmi.core.lesson_status", "incomplete");
    } else {
        console.log("SCORM connection failed – demo mode.");
    }
}

/**
 * בונה מחרוזת קריאה למרצה לדוחות ה-SCORM (cmi.comments)
 * פורמט לדוגמה:
 * קורס: אתיקה... | תרומה: 4 | המלצה: 4 | רצון לעוד קורס: 2 | משוב: "היה מעולה" | זמן: 2025-12-10T12:38:06.168Z
 */
function buildHumanReadableSurveyString(data) {
    const parts = [];

    parts.push("קורס: " + (data.courseName || ""));

    parts.push("תרומה: " + (data.contribution || "לא נבחר"));
    parts.push("המלצה: " + (data.recommend || "לא נבחר"));
    parts.push("רצון לעוד קורס: " + (data.nextCourse || "לא נבחר"));

    if (data.feedback && data.feedback.trim() !== "") {
        // מחליפים גרשיים כפולים כדי שלא ישברו CSV
        const cleanFeedback = data.feedback.replace(/"/g, "'");
        parts.push('משוב: "' + cleanFeedback + '"');
    }

    parts.push("זמן: " + (data.timestamp || ""));

    return parts.join(" | ");
}

// שמירת הנתונים ל-LMS (אם מחוברים)
function saveSurveyToLMS(surveyData) {
    if (!scormConnected || !window.pipwerks || !pipwerks.SCORM) {
        // מצב דמו – שומרים לקונסול בלבד
        console.log("Survey data (demo mode):", surveyData);
        return false; // לא נשמר ב-LMS
    }

    try {
        // 1. JSON גולמי לניתוח מתקדם (Power BI / Excel וכו')
        const suspendJSON = JSON.stringify(surveyData);
        pipwerks.SCORM.set("cmi.suspend_data", suspendJSON);

        // 2. מחרוזת קריאה למרצה לדוחות ה-SCORM
        const humanReadable = buildHumanReadableSurveyString(surveyData);
        pipwerks.SCORM.set("cmi.comments", humanReadable);

        // 3. סטטוס והצלה, כמו במצגות
        pipwerks.SCORM.set("cmi.core.lesson_status", "completed");
        pipwerks.SCORM.save();

        console.log("Survey data saved to LMS:", suspendJSON, humanReadable);
        return true; // נשמר ב-LMS
    } catch (err) {
        console.error("Error saving survey to LMS:", err);
        return false;
    }
}

// סגירת החיבור ל-SCORM כשעוזבים את העמוד
function quitScorm() {
    if (scormConnected && window.pipwerks && pipwerks.SCORM) {
        pipwerks.SCORM.quit();
        scormConnected = false;
        console.log("SCORM connection closed.");
    }
}

/* =========================================
   Units search (live filter)
   ========================================= */

function setupSearch() {
    const desktopInput = document.getElementById("search-input");
    const desktopButton = document.getElementById("search-button");
    const mobileInput = document.getElementById("search-input-mobile");
    const mobileButton = document.getElementById("search-button-mobile");

    function runSearch(query) {
        const value = (query || "").toString().trim().toLowerCase();
        const cards = document.querySelectorAll(".unit-card");

        cards.forEach((card) => {
            const titleAttr = (card.getAttribute("data-unit-title") || "").toLowerCase();
            const cardText = card.innerHTML.toLowerCase(); // לפי ההעדפה שלך – innerHTML
            const matches = titleAttr.includes(value) || cardText.includes(value);
            card.style.display = matches ? "" : "none";
        });
    }

    // Desktop – חיפוש תוך כדי הקלדה + כפתור + Enter
    if (desktopInput) {
        desktopInput.addEventListener("input", function () {
            runSearch(desktopInput.value);
        });

        desktopInput.addEventListener("keydown", function (ev) {
            if (ev.key === "Enter") {
                ev.preventDefault();
                runSearch(desktopInput.value);
            }
        });
    }
    if (desktopButton) {
        desktopButton.addEventListener("click", function (ev) {
            ev.preventDefault();
            runSearch(desktopInput ? desktopInput.value : "");
        });
    }

    // Mobile – אותו דבר
    if (mobileInput) {
        mobileInput.addEventListener("input", function () {
            runSearch(mobileInput.value);
        });

        mobileInput.addEventListener("keydown", function (ev) {
            if (ev.key === "Enter") {
                ev.preventDefault();
                runSearch(mobileInput.value);
            }
        });
    }
    if (mobileButton) {
        mobileButton.addEventListener("click", function (ev) {
            ev.preventDefault();
            runSearch(mobileInput ? mobileInput.value : "");
        });
    }
}

/* =========================================
   Survey form – validate + send to SCORM
   ========================================= */

function setupSurveyForm() {
    const form = document.getElementById("survey-form");
    if (!form) return;

    const messageBox = document.getElementById("survey-message");

    function showMessage(type, text) {
        if (!messageBox) return;

        // איפוס מחלקות
        messageBox.className = "";
        messageBox.classList.add("mt-3", "p-3", "rounded-3");

        if (type === "error") {
            messageBox.classList.add("alert", "alert-danger");
        } else if (type === "success") {
            messageBox.classList.add("alert", "alert-success");
        } else {
            messageBox.classList.add("alert", "alert-warning");
        }

        messageBox.innerHTML = text;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        // איסוף נתונים מהטופס
        const courseName = document.getElementById("course-name")?.value || "";
        const feedbackText = document.getElementById("feedback-text")?.value || "";

        const contribution = form.querySelector("input[name='q-contribution']:checked");
        const recommend = form.querySelector("input[name='q-recommend']:checked");
        const nextCourse = form.querySelector("input[name='q-next-course']:checked");

        // ולידציה בסיסית – 3 שאלות לייקרט חובה (טקסט חופשי לא חובה)
        if (!contribution || !recommend || !nextCourse) {
            showMessage("error", "נא לענות על כל שאלות דירוג שביעות הרצון לפני שליחת המשוב.");
            return;
        }

        const surveyData = {
            courseName: courseName,
            feedback: feedbackText,
            contribution: contribution.value,
            recommend: recommend.value,
            nextCourse: nextCourse.value,
            timestamp: new Date().toISOString()
        };

        const savedToLMS = saveSurveyToLMS(surveyData);

        if (savedToLMS) {
            // מצב אמיתי – LMS
            showMessage(
                "success",
                "המשוב נשלח ונשמר במערכת ה-LMS. תודה רבה על השתתפותך!"
            );
        } else {
            // מצב דמו – לדפדפן או הרצה מקומית
            showMessage(
                "success",
                "המשוב נשלח (דמו) – הנתונים נשמרו רק locally לצורך בדיקות. במצב LMS אמיתי הם יישמרו אוטומטית במערכת."
            );
        }

        // ננעל את הכפתור כדי שלא יספימו
        const submitBtn = document.getElementById("btn-submit");
        if (submitBtn) {
            submitBtn.disabled = true;
        }
    });
}

/* =========================================
   Init on load + quit on unload
   ========================================= */

document.addEventListener("DOMContentLoaded", function () {
    initScorm();
    setupSearch();
    setupSurveyForm();
});

window.addEventListener("unload", quitScorm);
